package com.cg.employeemanagementsystem.repo;

import com.cg.employeemanagementsystem.dto.Employee;

public class EmployeeRepositoryImpl implements EmployeeRepository {
	
	private static EmployeeRepository employeeRepository;
	
	private EmployeeRepositoryImpl() {
		
		
	}
	
	public static EmployeeRepository getInstance() {
		if(employeeRepository == null) {
			employeeRepository = new EmployeeRepositoryImpl();
			return employeeRepository;
		}
		else {
			return employeeRepository;
		}
	}

	private Employee employees[] = new Employee[10];
	private static int counter = 0;
	// we should have only one object
	// Design Pattern : its a solution to a common problem. getting a single object
	// singelton design pattern : it is responsible to provide the single object (one Obj)
	
	// to avoid the memory wastage.
	
	@Override
	public String addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteEmployeeById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee getEmployeeById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee[] getEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateEmployee(String id, Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}

}
