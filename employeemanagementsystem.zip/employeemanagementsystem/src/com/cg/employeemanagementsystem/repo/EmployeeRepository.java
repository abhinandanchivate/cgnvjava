package com.cg.employeemanagementsystem.repo;

import java.util.List;

import com.cg.employeemanagementsystem.dto.Employee;

public interface EmployeeRepository {
	
	public String addEmployee(Employee employee);
	public String deleteEmployeeById(String id);
	public Employee getEmployeeById(String id);
	public Employee[] getEmployees();
	public String updateEmployee
	(String id, Employee employee);

}
