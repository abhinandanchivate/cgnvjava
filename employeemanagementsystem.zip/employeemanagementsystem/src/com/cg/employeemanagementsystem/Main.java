package com.cg.employeemanagementsystem;

import com.cg.employeemanagementsystem.repo.EmployeeRepository;
import com.cg.employeemanagementsystem.repo.EmployeeRepositoryImpl;

public class Main {

	public static void main(String[] args) {
		
		EmployeeRepository employeeRepository = EmployeeRepositoryImpl.getInstance();
		
		EmployeeRepository employeeRepository2 = EmployeeRepositoryImpl.getInstance();
		
		EmployeeRepository employeeRepository3 = EmployeeRepositoryImpl.getInstance();
		
		System.out.println(employeeRepository== employeeRepository2);
		
		System.out.println(employeeRepository3== employeeRepository2);
		
		System.out.println(employeeRepository== employeeRepository3);
		
		System.out.println(employeeRepository.hashCode());
		System.out.println(employeeRepository2.hashCode());
		System.out.println(employeeRepository3.hashCode());
		System.out.println(employeeRepository.equals(employeeRepository2));
		System.out.println(employeeRepository3.equals(employeeRepository2));
		System.out.println(employeeRepository.equals(employeeRepository3));
		
		
		
		
	}
}
