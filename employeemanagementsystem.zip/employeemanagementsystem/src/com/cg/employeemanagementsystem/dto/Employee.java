package com.cg.employeemanagementsystem.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Employee {

	private String empId;
	private String firstName;
	private String lastName;
	private String location;
	private int deptNo;
	private float empSalary;
	
	
	
	
}
