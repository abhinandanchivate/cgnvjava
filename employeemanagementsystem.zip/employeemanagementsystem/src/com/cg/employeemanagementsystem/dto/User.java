package com.cg.employeemanagementsystem.dto;

import lombok.Data;

@Data
public class User {
	
	private String userId; // its a ref . 
	// where this ref will be allocated?
	private String password;
	private String firstName;
	private String lastName;
	
	

}
